#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){

    FILE *f = fopen("data/data.txt","w");

    srand(time(NULL));

    for(int i=0;i<1000;i++){
        fprintf(f,"%d\n", rand()%10000);
    }

    fclose(f);

    printf("Fichier de données généré\n");

    return 0;
}