#include <stdio.h>
#include <stdlib.h>
#include "external_sort.h"

#define MAX 100000

int compare(const void *a, const void *b){
    return (*(int*)a - *(int*)b);
}

void external_sort(char *input_file, char *output_file){

    FILE *in = fopen(input_file,"r");
    FILE *out = fopen(output_file,"w");

    int *tab = malloc(MAX * sizeof(int));
    int n = 0;

    while(fscanf(in,"%d",&tab[n]) != EOF){
        n++;
    }

    qsort(tab,n,sizeof(int),compare);

    for(int i=0;i<n;i++){
        fprintf(out,"%d\n",tab[i]);
    }

    fclose(in);
    fclose(out);
}