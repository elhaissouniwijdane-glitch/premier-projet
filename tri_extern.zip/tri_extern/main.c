#include <stdio.h>
#include "external_sort.h"

int main() {

    char input[] = "data/data1.txt";
    char output[] = "data/output/sorted.txt";

    external_sort(input, output);

    printf("Tri terminé\n");

    return 0;
}