#ifndef EXTERNAL_SORT_H
#define EXTERNAL_SORT_H

void external_sort(char *input_file, char *output_file);

#endif